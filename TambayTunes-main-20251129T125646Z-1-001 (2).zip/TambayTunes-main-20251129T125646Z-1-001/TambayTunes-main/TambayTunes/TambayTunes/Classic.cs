﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TambayTunes
{
    public partial class Classic : UserControl
    {
        public Classic()
        {
            InitializeComponent();
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            roomwaview r = new roomwaview();
            r.Show();
            this.Visible = false;

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            roomwaview r = new roomwaview();
            r.Show();
            this.Visible = false;

        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            riverflows r = new riverflows();
            r.Show();
            this.Visible = false;

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            riverflows r = new riverflows();
            r.Show();
            this.Visible = false;

        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {
            reminiscent remi = new reminiscent();
            remi.Show();
            this.Visible = false;

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            reminiscent remi = new reminiscent();
            remi.Show();
            this.Visible = false;

        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            hisheaven heaven = new hisheaven();
            heaven.Show();
            this.Visible = false;

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            hisheaven heaven = new hisheaven();
            heaven.Show();
            this.Visible = false;

        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            maybe m = new maybe();
            m.Show();
            this.Visible = false;

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            maybe m = new maybe();
            m.Show();
            this.Visible = false;

        }
    }
}
