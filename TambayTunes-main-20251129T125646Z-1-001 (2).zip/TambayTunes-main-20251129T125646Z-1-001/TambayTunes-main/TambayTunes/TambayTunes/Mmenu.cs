﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TambayTunes
{
    public partial class Mmenu : Form
    {
        bool sidebarExpand;
        public Mmenu()
        {
            InitializeComponent();
        }
        private void LoadPage(UserControl page)
        {
            page.Dock = DockStyle.Fill;
            bigp.Controls.Clear();
            bigp.Controls.Add(page);
            page.BringToFront();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            LoadPage(new jazz());
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void SidebarTimer_Tick(object sender, EventArgs e)
        {
            if (sidebarExpand)
            {
                sidebar.Width -= 10;
                if(sidebar.Width == sidebar.MinimumSize.Width)
                {
                    sidebarExpand = false;
                    sidebarTimer.Stop();
                }
            } 
            else
            {
                sidebar.Width += 10;    
                if(sidebar.Width == sidebar.MaximumSize.Width)
                {
                    sidebarExpand = true;
                    sidebarTimer.Stop();
                }
            }
                
            
            
        }
        
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            sidebarTimer.Start();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
           

        }

        private void label5_Click(object sender, EventArgs e)
        {
            LoadPage(new Classic());
        }

        private void label1_Click(object sender, EventArgs e)
        {
            LoadPage(new pop());
        }

        private void label4_Click(object sender, EventArgs e)
        {
            LoadPage(new rock());
        }

        private void label3_Click(object sender, EventArgs e)
        {
            LoadPage(new rnb());

        }

        private void label9_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            InitializeComponent();

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            riverflows r = new riverflows();
            r.Show();
            this.Close();
        }

        private void pictureBox26_Click(object sender, EventArgs e)
        {
        }
    }
}
