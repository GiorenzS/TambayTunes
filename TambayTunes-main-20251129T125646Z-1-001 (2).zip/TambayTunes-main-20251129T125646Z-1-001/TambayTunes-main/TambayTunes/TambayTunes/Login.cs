﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TambayTunes
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void login_b_Click(object sender, EventArgs e)
        {
            Mmenu m = new Mmenu();
            m.Show();
            this.Close();
        }
    }
}
