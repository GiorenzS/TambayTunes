﻿
namespace TambayTunes
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.panel1 = new System.Windows.Forms.Panel();
            this.text2_l = new System.Windows.Forms.Label();
            this.login_b = new System.Windows.Forms.Button();
            this.SignUp_ll = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.text1_l = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rem_cb = new System.Windows.Forms.CheckBox();
            this.PASS_L = new System.Windows.Forms.Label();
            this.email_tb = new System.Windows.Forms.TextBox();
            this.password_tb = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SlateBlue;
            this.panel1.Controls.Add(this.text2_l);
            this.panel1.Controls.Add(this.login_b);
            this.panel1.Controls.Add(this.SignUp_ll);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.text1_l);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.rem_cb);
            this.panel1.Controls.Add(this.PASS_L);
            this.panel1.Controls.Add(this.email_tb);
            this.panel1.Controls.Add(this.password_tb);
            this.panel1.Location = new System.Drawing.Point(252, 139);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(741, 497);
            this.panel1.TabIndex = 14;
            // 
            // text2_l
            // 
            this.text2_l.AutoSize = true;
            this.text2_l.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text2_l.ForeColor = System.Drawing.Color.White;
            this.text2_l.Location = new System.Drawing.Point(152, 435);
            this.text2_l.Name = "text2_l";
            this.text2_l.Size = new System.Drawing.Size(442, 25);
            this.text2_l.TabIndex = 10;
            this.text2_l.Text = "This page is protected by Gaagle to ensure you\'re not a bot.";
            // 
            // login_b
            // 
            this.login_b.BackColor = System.Drawing.Color.SlateBlue;
            this.login_b.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.login_b.Font = new System.Drawing.Font("Gill Sans Ultra Bold Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login_b.ForeColor = System.Drawing.Color.Black;
            this.login_b.Location = new System.Drawing.Point(185, 285);
            this.login_b.Name = "login_b";
            this.login_b.Size = new System.Drawing.Size(366, 55);
            this.login_b.TabIndex = 11;
            this.login_b.Text = "LOGIN";
            this.login_b.UseVisualStyleBackColor = false;
            this.login_b.Click += new System.EventHandler(this.login_b_Click);
            // 
            // SignUp_ll
            // 
            this.SignUp_ll.AutoSize = true;
            this.SignUp_ll.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SignUp_ll.LinkColor = System.Drawing.Color.White;
            this.SignUp_ll.Location = new System.Drawing.Point(328, 410);
            this.SignUp_ll.Name = "SignUp_ll";
            this.SignUp_ll.Size = new System.Drawing.Size(114, 25);
            this.SignUp_ll.TabIndex = 9;
            this.SignUp_ll.TabStop = true;
            this.SignUp_ll.Text = "SIGN UP NOW";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(268, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 56);
            this.label1.TabIndex = 1;
            this.label1.Text = "LOGIN";
            // 
            // text1_l
            // 
            this.text1_l.AutoSize = true;
            this.text1_l.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text1_l.ForeColor = System.Drawing.Color.White;
            this.text1_l.Location = new System.Drawing.Point(152, 410);
            this.text1_l.Name = "text1_l";
            this.text1_l.Size = new System.Drawing.Size(179, 25);
            this.text1_l.TabIndex = 8;
            this.text1_l.Text = "New to Tambay Tunes?";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(180, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 29);
            this.label2.TabIndex = 2;
            this.label2.Text = "EMAIL";
            // 
            // rem_cb
            // 
            this.rem_cb.AutoSize = true;
            this.rem_cb.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rem_cb.ForeColor = System.Drawing.Color.White;
            this.rem_cb.Location = new System.Drawing.Point(185, 346);
            this.rem_cb.Name = "rem_cb";
            this.rem_cb.Size = new System.Drawing.Size(187, 29);
            this.rem_cb.TabIndex = 7;
            this.rem_cb.Text = "REMEMBER ME";
            this.rem_cb.UseVisualStyleBackColor = true;
            // 
            // PASS_L
            // 
            this.PASS_L.AutoSize = true;
            this.PASS_L.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PASS_L.ForeColor = System.Drawing.Color.White;
            this.PASS_L.Location = new System.Drawing.Point(186, 197);
            this.PASS_L.Name = "PASS_L";
            this.PASS_L.Size = new System.Drawing.Size(158, 29);
            this.PASS_L.TabIndex = 3;
            this.PASS_L.Text = "PASSWORD";
            // 
            // email_tb
            // 
            this.email_tb.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email_tb.Location = new System.Drawing.Point(185, 144);
            this.email_tb.Name = "email_tb";
            this.email_tb.Size = new System.Drawing.Size(366, 32);
            this.email_tb.TabIndex = 5;
            // 
            // password_tb
            // 
            this.password_tb.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password_tb.Location = new System.Drawing.Point(185, 229);
            this.password_tb.Name = "password_tb";
            this.password_tb.Size = new System.Drawing.Size(366, 32);
            this.password_tb.TabIndex = 6;
            this.password_tb.UseSystemPasswordChar = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(357, -104);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(545, 345);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1184, 688);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Login";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label text2_l;
        private System.Windows.Forms.Button login_b;
        private System.Windows.Forms.LinkLabel SignUp_ll;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label text1_l;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox rem_cb;
        private System.Windows.Forms.Label PASS_L;
        private System.Windows.Forms.TextBox email_tb;
        private System.Windows.Forms.TextBox password_tb;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}