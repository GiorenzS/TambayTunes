﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TambayTunes
{
    public partial class riverflows : Form
    {
        public riverflows()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string f = "C:\\Users\\User\\Desktop\\Main Proj - Tambay Tunes\\tambay music\\lv_0_20251129002931.mp4";
            axWindowsMediaPlayer2.URL = f;
        }

        private void label14_Click(object sender, EventArgs e)
        {
            hisheaven heaven = new hisheaven();
            heaven.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            reminiscent remi = new reminiscent();
            remi.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            roomwaview r = new roomwaview();
            r.Show();
            this.Close();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            maybe m = new maybe();
            m.Show();
            this.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Mmenu m = new Mmenu();
            m.Show();
            this.Close();
        }
    }
}
