﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TambayTunes
{
    public partial class jazz : UserControl
    {
        public jazz()
        {
            InitializeComponent();
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            bluengreen b = new bluengreen();
            b.Show();
            this.Visible = false;

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            bluengreen b = new bluengreen();
            b.Show();
            this.Visible = false;

        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            spain s = new spain();
            s.Show();
            this.Visible = false;

        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            cantalope c = new cantalope();
            c.Show();
            this.Visible = false;

        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            cantalope c = new cantalope();
            c.Show();
            this.Visible = false;

        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {
            sowhta sw = new sowhta();
            sw.Show();
            this.Visible = false;

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            sowhta sw = new sowhta();
            sw.Show();
            this.Visible = false;

        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            Songfmfather so = new Songfmfather();
            so.Show();
            this.Visible = false;

        }
    }
}
