﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TambayTunes
{
    public partial class spain : Form
    {
        public spain()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string f = "C:\\Users\\User\\Desktop\\Main Proj - Tambay Tunes\\tambay music\\spain.mp4";
            axWindowsMediaPlayer2.URL = f;
        }

        private void label5_Click(object sender, EventArgs e)
        {
            sowhta sw = new sowhta();
            sw.Show();
            this.Close();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Songfmfather so = new Songfmfather();
            so.Show();
            this.Close();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            bluengreen b = new bluengreen();
            b.Show();
            this.Close();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            cantalope c = new cantalope();
            c.Show();
            this.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Mmenu m = new Mmenu();
            m.Show();
            this.Close();
        }
    }
}
